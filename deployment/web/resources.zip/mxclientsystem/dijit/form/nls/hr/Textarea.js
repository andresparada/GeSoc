//>>built
define("dijit/form/nls/hr/Textarea",({iframeEditTitle:"područje uređivanja",iframeFocusTitle:"okvir područja uređivanja"}));
